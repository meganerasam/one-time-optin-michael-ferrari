const express = require("express");
const { oneTimeOptIn, oneTimeOptInWithName } = require("../controller/oneTimeOptInController.js");

const router = express.Router();

router.get('/opt-in/:email', oneTimeOptIn);
router.get('/opt-in/:email/:name', oneTimeOptInWithName);

module.exports = router;